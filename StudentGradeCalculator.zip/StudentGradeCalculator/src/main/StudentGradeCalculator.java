package main;

import java.util.Scanner;
import java.util.Arrays;

public class StudentGradeCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GradeCalculator calculator = new GradeCalculator(); // Create once

        System.out.println("Welcome to Student Grade Calculator!");
        System.out.print("How many students do you want to enter? ");
        int numStudents = scanner.nextInt();
        scanner.nextLine(); // consume leftover newline

        Student[] students = new Student[numStudents]; // optional, store all students

        for (int i = 0; i < numStudents; i++) {
            System.out.println("\nEntering data for student #" + (i + 1));

            // 1. Get student name
            System.out.print("Enter student's name: ");
            String name = scanner.nextLine();

            // 2. Get number of subjects and marks
            System.out.print("How many subjects for " + name + "? ");
            int numSubjects = scanner.nextInt();
            int[] subjectMarks = new int[numSubjects];

            for (int j = 0; j < numSubjects; j++) {
                System.out.print("Enter mark for subject " + (j + 1) + ": ");
                subjectMarks[j] = scanner.nextInt();
            }
            scanner.nextLine(); // consume leftover newline

            // 3. Create Student object
            Student student = new Student(name, subjectMarks);

            // 4. Calculate total, average, and grade
            calculator.calculateTotal(student);
            calculator.calculateAverage(student);
            calculator.calculateGrade(student);

            // Store student
            students[i] = student;

            // 5. Display results
            System.out.println("\nResults for " + student.getName() + ":");
            System.out.println("Marks: " + Arrays.toString(student.getSubjectMarks()));
            System.out.println("Total: " + student.getTotal());
            System.out.printf("Average: %.2f\n", student.getAverage());
            System.out.println("Grade: " + student.getGrade());
        }

        scanner.close();
    }
}
