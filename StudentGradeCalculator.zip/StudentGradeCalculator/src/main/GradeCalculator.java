package main;

public class GradeCalculator {

    /**
     * Calculate total marks of the student
     * @param student - the Student object
     */
    public void calculateTotal(Student student) {
        int total = 0;
        int[] marks = student.getSubjectMarks();
        for (int mark : marks) {
            total += mark;
        }
        student.setTotal(total);
    }

    /**
     * Calculate average marks of the student
     * @param student - the Student object
     */
    public void calculateAverage(Student student) {
        int total = student.getTotal();
        int numSubjects = student.getSubjectMarks().length;
        double average = (double) total / numSubjects; //(double) so it will shorten decimals
        student.setAverage(average);
    }

    /**
     * Determine the grade of the student based on average
     * @param student - the Student object
     */
    public void calculateGrade(Student student) {
        double average = student.getAverage();
        char grade;

        if (average >= 80) {
            grade = 'A';
        } else if (average >= 70) {
            grade = 'B';
        } else if (average >= 60) {
            grade = 'C';
        } else if (average >= 50) {
            grade = 'D';
        } else {
            grade = 'F';
        }

        student.setGrade(grade);
    }
}
