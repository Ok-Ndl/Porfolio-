package main;

public class Student {
	private String name;
	private int [] subjectMarks;
	private int total;
	private double average;
	private char grade;
	//Variables are private meaning they cannot be directly accessed 
	
	//Student identity 
	public Student(String name, int[] subjectMarks) {
		this.name = name;
		this.subjectMarks = subjectMarks;
		this.total = 0;    // will calculate later
        this.average = 0;  // will calculate later
        this.grade = ' ';
	}
	
	// Updates Student information
	public void setName(String newName) {
		name = newName;
	}
	
	public void setSubjectMarks(int[] newSubjectMarks) {
		subjectMarks = newSubjectMarks;
	}
	
	public void setAverage(double newAverage) {
		average = newAverage;
	}
	
	public void setTotal(int newTotal) {
		total = newTotal;
	}
	
	public void setGrade(char newGrade) {
		grade = newGrade;
	}
	
	//the following syntax gives programmer a way to access above mentioned variables
	public String getName() {
		return name;
	}
	
	public int[] getSubjectMarks() {
		return subjectMarks;
	}
	
	public double getAverage() {
		return average;
	}
	
	public int getTotal() {
		return total;
	}
	
	public char getGrade() {
		return grade;
	}
	
	
}
