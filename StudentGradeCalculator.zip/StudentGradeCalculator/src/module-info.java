/**
 * 
 */
/**
 * 
 */
module StudentGradeCalculator {
	requires java.desktop;
}